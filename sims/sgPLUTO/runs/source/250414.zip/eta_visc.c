#include "pluto.h"
#include <stdio.h>

/*---------------------------------------------------------------------------*/
/*---- Specification of explicit first and second viscosity coefficients ----*/
/*---------------------------------------------------------------------------*/

void eta_visc_func(real *v, real x1, real x2, real x3, 
                   real *eta1_visc, real *eta2_visc )
{
  /*assume spherical polars*/
  double z, fz, R, transition_height, transition_radius;
  double visc, vert_coord;
  
  R = x1*sin(x2);
  z = x1*cos(x2); 

  /*normal, smooth viscosity*/
  visc = 0.0; 
  if(g_inputParam[nu] > 0.0)       visc  = g_inputParam[nu]*g_unitLength*g_unitLength*omega_k(g_unitLength);
  if(g_inputParam[nu_alpha] > 0.0) visc  = g_inputParam[nu_alpha]*sqrt(csq(R))*bigH(R);
  
  visc *= surface_density(g_unitLength)/surface_density(R);

  fz = 1.0; 

  if(g_inputParam[visc_rtrans] > 0.0){
    double fr;
    fr = 0.5*(1.0 + tanh((R - g_unitLength)/(g_inputParam[bump_width]*bigH(g_unitLength))));
    fz *= fr;
    fz += (1.0 - fr)*g_inputParam[visc_jump_amp];
  }

  if(g_inputParam[visc_rtrans] < 0.0){
    double fr;
    fr = 0.5*(1.0 + tanh((R - g_unitLength)/(g_inputParam[bump_width]*bigH(g_unitLength))));
    fz *= 1.0 - fr;
    fz += fr*g_inputParam[visc_jump_amp];
  }



//  } else { /*transition radius is independent of height*/
//  fz = 1.0 + 0.5*(g_inputParam[visc_jump_amp] - 1.0)*(1.0 - tanh( (R - g_unitLength )/(g_inputParam[bump_width]*bigH(g_unitLength)) )); 
//  }

  *eta1_visc = v[RHO]*visc*fz;
  *eta2_visc = 0.0;
}
