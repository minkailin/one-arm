      REAL totlsit, totnrit, nrpert, lspert, tot_trout, tot_tsr,
     .     tot_tsyn, tot_tcom, lstime
      common /impacct/ totlsit, totnrit, tot_trout, tot_tsr, 
     .                 tot_tsyn, tot_tcom, lstime
      integer cgerrcrit
      common /cgerr/ cgerrcrit
